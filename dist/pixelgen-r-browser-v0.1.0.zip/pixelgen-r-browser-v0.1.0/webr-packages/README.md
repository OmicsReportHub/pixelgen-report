# Pixelgen webR R Environment

This directory defines the downloadable R package release used by
`index.html`.

It follows the same contract as `rnaseq-report`, but without publishing a
GitHub Pages package snapshot:

1. Read a version from `VERSION`.
2. Read package refs from `packages`.
3. Build a webR package repository with `r-wasm/actions`.
4. Archive the repository as a release ZIP.
5. Convert the repository into a browser-loadable webR library bundle.
6. Upload the HTML page, package ZIP, and library bundle files to a GitHub
   Release.

The split library bundle is the fastest path for interactive browser use. In
`index.html`, use **Mount bundle** and choose both:

```text
pixelgen-report-webr-library-v0.1.0.data.gz
pixelgen-report-webr-library-v0.1.0.js.metadata
```

The ZIP contains the same two files and is useful for download/archive:

```text
pixelgen-report-webr-library-v0.1.0.zip
```

The mounted library is session-scoped browser state. Mount it again after a
browser refresh.

## webR Build Patches

- `patches/prepare_bpcells_source.py` downloads the `BPCells` `v0.3.1` R
  package source, patches a few HDF5 dimension casts, and disables Clang's
  C++11 narrowing diagnostic for additional HDF5 dimension initializer lists
  that Emscripten rejects during the wasm build. It also removes BPCells'
  duplicate explicit `-lz` link flag because the webR HDF5 flags already supply
  zlib, and adds `hwy/timer.cc` to BPCells' vendored Highway static-library
  build so `BPCells.so` does not leave Highway timer symbols unresolved at
  browser load time.
- `patches/prepare_pixelatorr_source.py` downloads the `pixelatorR` `v0.17.1`
  source release for local webR compilation and makes `arrow` optional so the
  namespace can load in webR. Arrow-backed parquet/PXL functions still require a
  browser-compatible `arrow` package, which is not currently available.
- `upstream-binaries` lists official webR binary packages that the release
  workflow copies from `repo.r-wasm.org` after the local build. The graph stack
  and selected runtime dependencies used by `pixelatorR` are handled this way
  because their CRAN source builds are not reliable under the current webR
  toolchain.
- `patches/rwasm-c17.mk` keeps local builds aligned with webR's compiler
  settings.
- `patches/prepare_png_source.py` patches `png` for webR by replacing its
  CRAN-check-only dummy routine calls. Without this, `png.so` imports
  `R_registerRoutines` and `R_useDynamicSymbols` with an ABI that the browser
  runtime rejects.
